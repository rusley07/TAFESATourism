﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace SISJr.Models {
    public class ExcelParser {
        // Results
        public bool ParseCompleted { get; private set; }
        public int AddedUnits { get; private set; }
        public int AddedStudents { get; private set; }
        public int AddedQualifications { get; private set; }
        public int AddedEnrolments { get; private set; }
        public int ResultsSaved { get; private set; }
        public int AddedQualUnits { get; private set; }
        public int AddedQualStudents { get; private set; }
        public int SkippedUnits { get; private set; }
        public int SkippedQualifications { get; private set; }
        public int SkippedStudents { get; private set; }
        public string Errors { get; private set; }

        // Behaviour
        private string excelFileName;
        private Entities db;
        private bool createQualifications;
        private bool createStudents;
        private bool createUnits;
        private bool associateQualificationsStudents;
        private bool associateQualificationsStudentsInclUnits;
        private bool associateQualificationsUnits;
        private bool associateStudentsUnits;

        public ExcelParser(string excelFileName, Entities db,
            bool createQualifications = false, bool createStudents = false, bool createUnits = false,
            bool associateQualificationsStudents = false, bool associateQualificationsUnits = false, bool associateStudentsUnits = false,
            bool associateQualificationsStudentsInclUnits = false) {
            this.excelFileName = excelFileName;
            this.db = db;
            this.createQualifications = createQualifications;
            this.createStudents = createStudents;
            this.createUnits = createUnits;
            this.associateQualificationsStudents = associateQualificationsStudents;
            this.associateQualificationsStudentsInclUnits = associateQualificationsStudentsInclUnits;
            this.associateQualificationsUnits = associateQualificationsUnits;
            this.associateStudentsUnits = associateStudentsUnits;

            this.ParseCompleted = false;
            this.AddedEnrolments = 0;
            this.AddedQualifications = 0;
            this.AddedQualStudents = 0;
            this.AddedQualUnits = 0;
            this.AddedStudents = 0;
            this.AddedUnits = 0;
            this.SkippedQualifications = 0;
            this.SkippedStudents = 0;
            this.SkippedUnits = 0;
        }

        public async Task ParseAsync() {
            await Task.Run((Action)Parse);
        }

        public void Parse() {
            // only parse once
            if (ParseCompleted)
                return;

            // start up excel, load the file
            Excel.Application excel = new Excel.Application();
            Excel.Workbook workbook = excel.Workbooks.Open(excelFileName, ReadOnly: true);

            foreach (Excel.Worksheet worksheet in workbook.Worksheets) {

                Excel.Range range = worksheet.UsedRange;

                int numRows = range.Rows.Count;
                int numCols = range.Columns.Count;

                // the cognos reports consist of
                // - 10ish rows of junk (tafe logo, name of report, etc)
                // - a row of column headers telling us what data will follow
                // - several rows of data
                // - 2 rows of junk (page number, date generated, etc)

                // we start off looking for the column headers. that's the first row with no empty cells
                // then we read those headers. that tells us the structure of the data records following.
                // then we read those records

                bool foundHeaders = false;
                Dictionary<string, int> headers = new Dictionary<string, int>(); // which column is which
                bool unitdata = false; // enough data to identify a unit
                bool createunitdata = false; // enough data to not just identify a unit, but to create a unit in our database if it is not already there
                bool studentdata = false; // enough data to identify a student
                bool createstudentdata = false; // enough data to not just identify a student, but to create a unit in our database if it is not already there
                bool qualdata = false; //  enough data to identify a qualification
                bool createqualdata = false; // enough data to not just identify a qualification, but to create a unit in our database if it is not already there
                int curRow = 0;
                foreach (Excel.Range row in range.Rows) {
                    curRow++;

                    if (!foundHeaders) {
                        // is this row the headers?
                        bool hasEmptyCols = false;
                        foreach (Excel.Range acell in row.Cells) {
                            if (acell.Value2 == null) {
                                // nope, not the headers
                                hasEmptyCols = true;
                                break;
                            }
                        }
                        if (!hasEmptyCols) {
                            // this is the headers!
                            int curCol = 0;
                            foreach (Excel.Range acell in row.Cells) {
                                curCol++;
                                headers[acell.Value2.ToString()] = curCol;
                            }
                            foundHeaders = true;

                            // handle the new format
                            if (headers.ContainsKey("SpridenID"))
                                headers["Student ID"] = headers["SpridenID"];
                            if (headers.ContainsKey("FIRSTNAME"))
                                headers["Student First Name"] = headers["FIRSTNAME"];
                            if (headers.ContainsKey("LASTNAME"))
                                headers["Student Last Name"] = headers["LASTNAME"];
                            if (headers.ContainsKey("QualCodeNational"))
                                headers["National Code"] = headers["QualCodeNational"];

                            // what sort of data is there?
                            if (headers.ContainsKey("Course Title")) {
                                unitdata = true;
                                if (createUnits &&
                                    headers.ContainsKey("Course Number") &&
                                    headers.ContainsKey("Nominal Hours")) {
                                    createunitdata = true;
                                }
                            }
                            if (headers.ContainsKey("Student ID")) {
                                studentdata = true;
                                if (createStudents &&
                                    headers.ContainsKey("Student First Name") &&
                                    headers.ContainsKey("Student Last Name")) {
                                    createstudentdata = true;
                                }
                            }
                            if (headers.ContainsKey("National Code")) {
                                qualdata = true;
                                if (createQualifications &&
                                    headers.ContainsKey("Program") &&
                                    headers.ContainsKey("Program Description")) {
                                    createqualdata = true;
                                }
                            }
                        }
                    } else {
                        // we have already read the headers

                        // check to see if this is the footer junk
                        if ("Package" == row.Cells[1, 1].Value2 &&
                            "Last Saved" == row.Cells[1, 3].Value2 &&
                            "Run Date" == row.Cells[1, 5].Value2) {
                            break;
                        }

                        // this row contains data. parse it
                        Unit unit = null;
                        Student student = null;
                        Qualification qualification = null;
                        if (unitdata) {
                            string courseCodeAndTitle = row.Cells[1, headers["Course Title"]].Value2;
                            if (courseCodeAndTitle != null) {
                                // cognos has the unit (national) code and title together in the same column, so we have to split them
                                string[] splits = courseCodeAndTitle.Split((char[])null, 2, StringSplitOptions.RemoveEmptyEntries);
                                string courseCode = splits[0]; // course code is the first 10 characters
                                string courseTitle = splits[1]; // courseCodeAndTitle.Substring(10).Trim(); // take off code, and trim whitespace
                                // check for the unit already in our database
                                unit = db.Units.Where(u => u.NationalCode == courseCode).FirstOrDefault();
                                if (unit == null) {
                                    if (createunitdata) {
                                        string tafeCode = row.Cells[1, headers["Course Number"]].Value2;
                                        var nh = row.Cells[1, headers["Nominal Hours"]].Value2;
                                        int? nominalHours = nh == null ? null : int.Parse(nh.ToString());

                                        unit = new Unit() { NationalCode = courseCode, Name = courseTitle, TafeCode = tafeCode, NominalHours = nominalHours };
                                        db.Units.Add(unit);
                                        db.SaveChanges();
                                        AddedUnits++;
                                    } else {
                                        SkippedUnits++;
                                    }
                                }
                            }
                        }
                        if (studentdata) {
                            string studentID = row.Cells[1, headers["Student ID"]].Value2;
                            if (studentID != null) {
                                // check for student already in db
                                student = db.Students.Where(s => s.StudentNumber == studentID).FirstOrDefault();
                                if (student == null) {
                                    if (createstudentdata) {
                                        string fn = row.Cells[1, headers["Student First Name"]].Value2;
                                        string ln = row.Cells[1, headers["Student Last Name"]].Value2;

                                        student = new Student() { StudentNumber = studentID, FirstName = fn, LastName = ln };
                                        db.Students.Add(student);
                                        db.SaveChanges();
                                        AddedStudents++;
                                    } else {
                                        SkippedStudents++;
                                    }
                                }
                            }
                        }
                        if (qualdata) {
                            string nationalCode = row.Cells[1, headers["National Code"]].Value2;
                            if (nationalCode != null) {
                                qualification = db.Qualifications.Where(q => q.NationalCode == nationalCode).FirstOrDefault();
                                if (qualification == null) {
                                    if (createqualdata) {
                                        string tafeCode = row.Cells[1, headers["Program"]].Value2;
                                        string name = row.Cells[1, headers["Program Description"]].Value2;
                                        qualification = new Qualification() { NationalCode = nationalCode, TafeCode = tafeCode, Name = name };
                                        db.Qualifications.Add(qualification);
                                        db.SaveChanges();
                                        AddedQualifications++;
                                    } else {
                                        SkippedQualifications++;
                                    }
                                }
                            }
                        }
                        if (associateStudentsUnits && student != null && unit != null) {
                            Enrolment enrolment = db.Enrolments.Where(e => e.Student_Id == student.Id && e.Unit_Id == unit.Id).FirstOrDefault();
                            if (enrolment == null) {
                                enrolment = new Enrolment() { Student_Id = student.Id, Unit_Id = unit.Id };
                                db.Enrolments.Add(enrolment);
                                db.SaveChanges();
                                AddedEnrolments++;
                            }
                            if (headers.ContainsKey("Grade")) {
                                string grade = row.Cells[1, headers["Grade"]].Value2;
                                enrolment.Result = grade;
                                db.Entry(enrolment).State = EntityState.Modified;
                                db.SaveChanges();
                                ResultsSaved++;
                            }
                        }
                        if (associateQualificationsStudents && qualification != null && student != null) {
                            if (!student.Qualifications.Contains(qualification)) {
                                if (associateQualificationsStudentsInclUnits) {
                                    student.addQual(qualification);
                                } else {
                                    student.Qualifications.Add(qualification);
                                }
                                db.Entry(student).State = EntityState.Modified;
                                db.SaveChanges();
                                AddedQualStudents++;
                            }
                        }
                        if (associateQualificationsUnits && qualification != null && unit != null) {
                            QualificationUnit qualunit = db.QualificationUnits.Where(qu => qu.Units_Id == unit.Id && qu.Qualifications_Id == qualification.Id).FirstOrDefault();
                            if (qualunit == null) {
                                qualunit = new QualificationUnit() { Units_Id = unit.Id, Qualifications_Id = qualification.Id }; //  Core = ??
                                db.QualificationUnits.Add(qualunit);
                                db.SaveChanges();
                                AddedQualUnits++;
                            }
                            if (headers.ContainsKey("Core/Elective")) {
                                string corestr = row.Cells[1, headers["Core/Elective"]].Value2;
                                bool core = (corestr != null && corestr.StartsWith("C", StringComparison.CurrentCultureIgnoreCase));
                                qualunit.Core = core;
                                db.Entry(qualunit).State = EntityState.Modified;
                                db.SaveChanges();
                            }
                        }
                    }
                }
                if (!foundHeaders) {
                    Errors += "No headers found on " + worksheet.Name + " (sheet is " + numCols + " columns wide, every row contains empty cells). ";
                }
                System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
            }
            // close file, quit excel
            workbook.Close(false);
            excel.Quit();

            // release resources (why can't they just use IDisposable?)
            System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(excel);
            workbook = null; excel = null;
            GC.Collect();

            ParseCompleted = true;
        }
    }
}