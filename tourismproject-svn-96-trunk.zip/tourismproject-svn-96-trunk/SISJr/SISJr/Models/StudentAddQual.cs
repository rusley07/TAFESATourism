﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SISJr.Models {

    public partial class Student {
        /// <summary>
        /// Adds a qualification to a student, and also adds all the units required by that
        /// qualification to the student's enrolments. If it has already been added, nothing is changed.
        /// </summary>
        /// <param name="qualification">The qualification to add</param>
        public void addQual(Qualification qualification) {
            // check to make sure it isn't already there
            if (this.Qualifications.Contains(qualification)) {
                return;
            }

            // add the qualification to the student object.
            this.Qualifications.Add(qualification);

            // loop through all the Units in the qualification
            foreach (var qu in qualification.QualificationUnits) {
                // if student does not already have an enrolment record for that unit, then add one
                if (this.Enrolments.Count(e => e.Unit_Id == qu.Units_Id) == 0) {
                    Enrolment enrolment = new Enrolment() { Student_Id = this.Id, Unit_Id = qu.Units_Id };
                    this.Enrolments.Add(enrolment);
                }
            }
        }
    }
}