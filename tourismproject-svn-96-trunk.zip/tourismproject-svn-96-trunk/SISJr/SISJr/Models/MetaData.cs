﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace SISJr.Models {
    // the model classes are auto-generated, so we have to put annotations in separate classes
    // and link them using the MetadataType annotation

    public class StudentMetaData {
        [Display(Name="Student Number")]
        [RegularExpression(@"^(S[0-9]{7})|(0[0-9]{8})$",
            ErrorMessage="Must be 9 digits (starting with a 0), or an 'S' followed by 7 digits")]
        [Required]
        public string StudentNumber { get; set; }
        [Display(Name = "First Name")]
        [MaxLength(255, ErrorMessage="Maximum length is 255 characters")]
        [Required]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        [MaxLength(255, ErrorMessage = "Maximum length is 255 characters")]
        [Required]
        public string LastName { get; set; }
    }

    public class QualificationMetaData {
        [Display(Name="Tafe Code")]
        [MaxLength(10, ErrorMessage = "Maximum length is 10 characters")]
        [Required]
        public string TafeCode { get; set; }
        [Display(Name = "National Code")]
        [MaxLength(10, ErrorMessage = "Maximum length is 10 characters")]
        [Required]
        public string NationalCode { get; set; }
        [Display(Name = "Qualification Title")]
        [MaxLength(255, ErrorMessage = "Maximum length is 255 characters")]
        [Required]
        public string Name { get; set; }
    }

    public class UnitMetaData {
        [Display(Name = "Tafe Code")]
        [MaxLength(10, ErrorMessage="Maximum length is 10 characters")]
        [Required]
        public string TafeCode { get; set; }
        [Display(Name = "National Code")]
        [MaxLength(12, ErrorMessage = "Maximum length is 12 characters")]
        [Required]
        public string NationalCode { get; set; }
        [Display(Name = "Unit Title")]
        [MaxLength(255, ErrorMessage = "Maximum length is 255 characters")]
        [Required]
        public string Name { get; set; }
        [Display(Name = "Nominal Hours")]
        [Range(1, int.MaxValue, ErrorMessage="Must be positive")]
        [Required]
        public Nullable<int> NominalHours { get; set; }
    }

    public class EnrolmentMetaData {
        [MaxLength(5, ErrorMessage = "Maximum length is 5 characters")]
        public string Result { get; set; }
    }

    [MetadataType(typeof(QualificationMetaData))]
    public partial class Qualification { }
    [MetadataType(typeof(UnitMetaData))]
    public partial class Unit { }
    [MetadataType(typeof(StudentMetaData))]
    public partial class Student { }
    [MetadataType(typeof(EnrolmentMetaData))]
    public partial class Enrolment { }
}