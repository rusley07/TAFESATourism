﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SISJr.Models {
    public partial class Enrolment {

        public static string[] FailingGrades = new string[] {
            "F", // Fail
            "FN", // Failed Not Assessed
            "W", // Withdrew
            "NS", // No Show
        };

        public static string[] ValidGrades = new string[] {
            "C", // Credit
            "D", // Distinction
            "F", // Fail
            "P", // Pass
            "PA", // Pass (non-graded)
            "FN", // Failed Not Assessed
            "ST", // Status granted through result transfer
            "W", // Withdrew
            "NS", // No Show
        };

        public bool IsPass() {
            if (this.Result == null) {
                return false;
            }
            if (FailingGrades.Contains(this.Result)) {
                return false;
            }
            //if (!ValidGrades.Contains(this.Result)) {
            //    throw new ArgumentException("Invalid Result");
            //}
            return true;
        }
    }
}