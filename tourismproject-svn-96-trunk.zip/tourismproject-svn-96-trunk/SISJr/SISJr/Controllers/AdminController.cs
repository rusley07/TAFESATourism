﻿using SISJr.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace SISJr.Controllers {
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller {
        private Entities db = new Entities();
        //
        // GET: /Admin/

        public ActionResult Index() {
            return View();
        }

        //
        // GET: /Admin/Nuke

        public ActionResult Nuke() {
            return View();
        }

        //
        // POST: /Admin/Nuke

        [HttpPost, ActionName("Nuke")]
        public ActionResult NukeConfirmed() {
            // time to nuke the db from orbit
            // (it's the only way to be sure)
            foreach (var enrolment in db.Enrolments) {
                db.Enrolments.Remove(enrolment);
            }
            foreach (var qu in db.QualificationUnits) {
                db.QualificationUnits.Remove(qu);
            }
            foreach (var qual in db.Qualifications) {
                db.Qualifications.Remove(qual);
            }
            foreach (var unit in db.Units) {
                db.Units.Remove(unit);
            }
            foreach (var student in db.Students) {
                db.Students.Remove(student);
            }
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ViewResult CognosUpload() {
            ViewBag.Message = "";
            return View();
        }

        [HttpPost]
        public ActionResult CognosUpload(HttpPostedFileBase file, bool addqualifications, bool addstudents, bool addunits,
            bool addqualstudents, bool addqualunits, bool addstudentunits, bool addqualstudentsincunits) {
            // Verify that the user selected a file
            if (file == null) {
                ViewBag.Message = "No file uploaded";
            } else if (file.ContentLength == 0) {
                ViewBag.Message = "File empty";
            } else {
                // Get file info
                var fileName = Path.GetFileName(file.FileName);
                var contentLength = file.ContentLength;
                var ext = Path.GetExtension(fileName);
                if (!ext.Equals(".xls", StringComparison.CurrentCultureIgnoreCase) &&
                    !ext.Equals(".xlsx", StringComparison.CurrentCultureIgnoreCase)) {
                    ViewBag.Message = "Invalid filename (" + fileName + "): only .xls or .xlsx files accepted";
                } else {
                    // Excel interop stuff can't open directly from the file.InputStream - it has to be given a filename to open
                    // so we need to save the uploaded file somewhere (and then delete it when we're done)

                    // Get temp file name
                    var temp = Path.GetTempPath(); // Get %TEMP% path
                    var tempfilename = Path.GetFileNameWithoutExtension(Path.GetRandomFileName()); // Get random file name without extension
                    var temppath = Path.Combine(temp, tempfilename + ext); // Get random file path using the same extension as the uploaded file

                    using (var fs = new FileStream(temppath, FileMode.CreateNew, FileAccess.Write)) {
                        file.InputStream.CopyTo(fs);
                    }
                    ViewBag.Message = "File uploaded successfully (" + contentLength + " bytes)";

                    var ep = new ExcelParser(temppath, db,
                        createQualifications: addqualifications, createStudents: addstudents, createUnits: addunits,
                        associateQualificationsStudents: addqualstudents, associateQualificationsUnits: addqualunits, associateStudentsUnits: addstudentunits,
                        associateQualificationsStudentsInclUnits: addqualstudentsincunits);
                    ep.Parse();

                    // delete temp file
                    System.IO.File.Delete(temppath);

                    string parsereport = ep.Errors;
                    if (ep.AddedQualifications > 0) {
                        parsereport += ep.AddedQualifications + " qualifications added. ";
                    }
                    if (ep.SkippedQualifications > 0) {
                        parsereport += ep.SkippedQualifications + " references to unknown qualifications skipped. ";
                    }
                    if (ep.AddedUnits > 0) {
                        parsereport += ep.AddedUnits + " units added. ";
                    }
                    if (ep.SkippedUnits > 0) {
                        parsereport += ep.SkippedUnits + " references to unknown units skipped. ";
                    }
                    if (ep.AddedQualUnits > 0) {
                        parsereport += ep.AddedQualUnits + " units added to qualifications. ";
                    }
                    if (ep.AddedStudents > 0) {
                        parsereport += ep.AddedStudents + " students added. ";
                    }
                    if (ep.SkippedStudents > 0) {
                        parsereport += ep.SkippedStudents + " references to unknown students skipped. ";
                    }
                    if (ep.AddedQualStudents > 0) {
                        parsereport += ep.AddedQualStudents + " qualification enrolments added. ";
                    }
                    if (ep.AddedEnrolments > 0) {
                        parsereport += ep.AddedEnrolments + " unit enrolments added. ";
                    }
                    if (ep.ResultsSaved > 0) {
                        parsereport += ep.ResultsSaved + " results updated. ";
                    }
                    ViewBag.Message += ". " + parsereport;

                    //return RedirectToAction("Index");
                }
            }
            return View();
        }

        //
        // GET: /Admin/ApproveAccounts

        public ActionResult ApproveAccounts() {
            var users = Membership.GetAllUsers().OfType<MembershipUser>();
            return View(users);
        }

        //
        // POST: /Admin/ApproveAccounts

        [HttpPost]
        public ActionResult ApproveAccounts(string username, bool staff, bool admin) {
            // update role membership to match that requested
            if (admin) {
                // admin implies staff
                staff = true;
                if (!Roles.IsUserInRole(username, "Admin"))
                    Roles.AddUserToRole(username, "Admin");
            } else {
                if (Roles.IsUserInRole(username, "Admin"))
                    Roles.RemoveUserFromRole(username, "Admin");
            }
            if (staff) {
                if (!Roles.IsUserInRole(username, "Staff"))
                    Roles.AddUserToRole(username, "Staff");
            } else {
                if (Roles.IsUserInRole(username, "Staff"))
                    Roles.RemoveUserFromRole(username, "Staff");
            }

            return RedirectToAction("ApproveAccounts");
        }

        protected override void Dispose(bool disposing) {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}
