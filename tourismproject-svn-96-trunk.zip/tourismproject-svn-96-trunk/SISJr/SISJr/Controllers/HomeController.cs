﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SISJr.Controllers {
    public class HomeController : Controller {
        public ActionResult Index() {
            // we don't use the home controller
            // but the account controller will redirect people here from login/logout
            // so let's catch them and send them on to somewhere useful
            return RedirectToActionPermanent("Index", "Student");
        }

        public ActionResult About() {
            return View();
        }
    }
}
