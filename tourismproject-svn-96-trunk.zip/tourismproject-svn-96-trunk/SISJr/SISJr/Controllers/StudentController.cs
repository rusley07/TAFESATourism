﻿using SISJr.Models;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.Mvc;


namespace SISJr.Controllers {
    public class StudentController : Controller {
        private Entities db = new Entities();

        //
        // GET: /Student/

        public ViewResult Index() {
            return View(db.Students.ToList());
        }

        //
        // GET: /Student/Details/5

        public ViewResult Details(int id) {
            Student student = db.Students.Find(id);
            return View(student);
        }

        //
        // GET: /Student/Search

        public ActionResult Search() {
            return View();
        }

        //
        // POST: /Student/Search

        [HttpPost]
        public ActionResult Search(Student student) {
            //Search for the student within the database with the id that is being passed in.
            Student foundStudent = db.Students.Where(p => p.StudentNumber == student.StudentNumber).FirstOrDefault();

            //Check if the student exists
            if (foundStudent != null) {
                // redirect to the details page
                return RedirectToAction("Details", new { id = foundStudent.Id });
            }

            //Student does not exist with that id, then display an error.
            ModelState.AddModelError("StudentNumber", "No student with that id!");
            return View();
        }

        //
        // GET: /Student/Create

        public ActionResult Create() {
            return View();
        }

        //
        // POST: /Student/Create

        [HttpPost]
        public ActionResult Create(Student student) {
            var existingStudent = db.Students.Where(s => s.StudentNumber == student.StudentNumber).FirstOrDefault();
            if (existingStudent != null) {
                ModelState.AddModelError("StudentNumber", "A student with that number already exists.");
            }
            if (ModelState.IsValid) {
                db.Students.Add(student);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(student);
        }

        //
        // GET: /Student/Edit/5

        public ActionResult Edit(int id) {
            Student student = db.Students.Find(id);

            return View(student);
        }

        //
        // POST: /Student/Edit/5

        [HttpPost]
        public ActionResult Edit(Student student) {
            if (ModelState.IsValid) {
                db.Entry(student).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Edit", "Student", new { id = student.Id });
            }

            return View(student);
        }

        // Qualification
        public ActionResult AddQualification(int studentid) {
            //Store the passed in studentid and add to a viewbag to pass to the next screen.
            ViewBag.AddStudentId = studentid;
            //redirect to the AddQualification screen with the entire list of qualifications passed in.
            return View(db.Qualifications.ToList());
        }

        public ActionResult AddQualification2(int qualificationId, int studentId) {
            //Find the student in the database with the same id that was passed in.
            Student student = db.Students.Find(studentId);
            //Find the qualification in the database with the same id that was passed in
            Qualification qualification = db.Qualifications.Find(qualificationId);

            //Loop through all the qualifcations the student is enrolled into.
            foreach (var qual in student.Qualifications) {
                //Check if the qualification already exists
                if (qual.Id == qualification.Id) {
                    //If already exists, redirect to the same student edit page.
                    return RedirectToAction("Edit", "Student", new { id = studentId });
                }
            }

            // add the qualification, and all units associated with it
            student.addQual(qualification);

            //Everything is fine, so save the edit of the student, and update database. Redirect to the same student edit page
            db.Entry(student).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Edit", "Student", new { id = studentId });

        }

        //View Units in qualification
        public ActionResult ViewUnits(int qualificationId, int studentId) {
            //Save the id that was passed in to a viewbag to pass to the next screen.
            ViewBag.ViewUnitsStudentId = studentId;

            //Find the student in the database with the same id.
            Student student = db.Students.Find(studentId);
            //Store all the students enrolments (units) in a list.
            List<Enrolment> enrolmentList = student.Enrolments.ToList<Enrolment>();

            //Find the qualification in the database with the same id
            Qualification qualification = db.Qualifications.Find(qualificationId);
            //Store all the Units in the qualification to a list.
            List<QualificationUnit> qualUnitList = qualification.QualificationUnits.ToList<QualificationUnit>();

            List<Enrolment> loopEnrolmentList = new List<Enrolment>();

            List<QualificationUnit> qualUnitCore = new List<QualificationUnit>();
            foreach (var qualUnit in qualUnitList) {
                //Find the student enrolment (unit) with the same id as the unit inside the selected qualification.
                Enrolment loopEnrol = enrolmentList.Find(x => x.Unit_Id == qualUnit.Units_Id);


                if (loopEnrol != null) {
                    //If it exists then check to see if the unit's id is the same as the last stored enrolment(unit)
                    if (qualUnit.Units_Id == loopEnrol.Unit_Id) {
                        //Add to the core list
                        qualUnitCore.Add(qualUnit);
                    }

                    loopEnrolmentList.Add(loopEnrol);
                }
            }

            //Store the unit core list and the chosen qualfication into viewbags
            ViewBag.qualUnitCore = qualUnitCore;
            ViewBag.qualificationViewUnits = qualification;

            //Sort the list by decending order of the enrolment results.
            List<Enrolment> SortedList = loopEnrolmentList.OrderByDescending(r => r.Result).ToList();

            return View(SortedList); //loopEnrolmentList
        }

        //ADD UNITS
        public ActionResult AddUnit(int studentid) {
            //Add the passed in student id to a viewbag to pass to the next screen.
            ViewBag.AddStudentId = studentid;
            //Pass to the addunit screen every unit in the database.
            return View(db.Units.ToList());
        }

        public ActionResult AddUnit2(int unitid, int studentid) {
            //find the student and the unit in the database with the id's that were passed in.
            Student student = db.Students.Find(studentid);
            Unit unit = db.Units.Find(unitid);

            //Create a new enrolment and pass in the ids.
            Enrolment enrolment = new Enrolment();
            enrolment.Student_Id = studentid;
            enrolment.Unit_Id = unitid;

            enrolment.Student = student;
            enrolment.Unit = unit;

            //loop through all the enrolments in the student object
            bool canAdd = true;
            foreach (var enrol in student.Enrolments) {
                //If the id of the selected unit is the same as a unit already enrolled by the student,
                //then set to not re-add the same unit.
                if (enrol.Unit_Id == unit.Id) {
                    canAdd = false;
                }
            }

            //If the enrolment(unit) can be added, then add the enrolment to the student object,
            //then modify that student in the database, and save the changes.
            if (canAdd) {
                student.Enrolments.Add(enrolment);

                db.Entry(student).State = EntityState.Modified;
                db.SaveChanges();
            }

            //Redirect to the edit page for the same student.
            return RedirectToAction("Edit", "Student", new { id = studentid });
        }

        //CHANGE GRADE
        public ActionResult ChangeGrade(int studentId) {
            Student student = db.Students.Find(studentId);

            return View(student);
        }

        [HttpPost]
        public ActionResult ChangeGrade(string theresult, int studentId, int unitId) {
            Enrolment enrolment1 = db.Enrolments.Find(studentId, unitId);
            enrolment1.Result = theresult;

            db.Entry(enrolment1).State = EntityState.Modified;
            db.SaveChanges();


            //return View();
            return RedirectToAction("Edit", "Student", new { id = studentId });
        }

        //Delete QUALIFICATION
        public ActionResult DeleteQualification(int qualificationId, int studentId) {
            //Find the student in the database with the same id that was passed in.
            Student student = db.Students.Find(studentId);
            //store the student in a viewbag to pass to the next screen.
            ViewBag.deleteStudent = student;

            //Find the qualification in the database with the same id that was passed in.
            Qualification qualification = db.Qualifications.Find(qualificationId);
            //Redirect to the DeleteQualification screen with the Qualification passed in.
            return View(qualification);
        }


        //When the "are you sure" DeleteQualifcation button is pressed
        [HttpPost, ActionName("DeleteQualification")]
        public ActionResult DeleteQualification2(int qualificationId, int studentId) {
            //Find the student and the qualfication in the database with the same ids that were passed in.
            Student student = db.Students.Find(studentId);
            Qualification qualification = db.Qualifications.Find(qualificationId);

            //Remove the qualification from the student object, and save the changes into the database
            student.Qualifications.Remove(qualification);
            db.Entry(student).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Edit", "Student", new { id = studentId });
        }


        //Delete UNIT
        public ActionResult DeleteEnrolment(int unitid, int studentid) {
            //Find the student in the database with the same id that was passed in.
            Student student = db.Students.Find(studentid);

            //Loop through all the enrolments(units) in the student.
            Enrolment enrolment = new Enrolment();
            foreach (var loopenrolment in student.Enrolments) {
                //if the id of the selected unit is the same as a unit inside the student enrolments,
                //then add the enrolment(unit) to the enrolment object.
                if (loopenrolment.Unit_Id == unitid) {
                    enrolment = loopenrolment;
                }
            }

            //store the enrolment object inside a viewbag to pass to the next screen.
            ViewBag.DeleteEnrolment = enrolment;

            //redirect to the deleteEnrolment screen with the student passed in.
            return View(student);
        }

        //When the "are you sure" DeleteEnrolment button is pressed
        [HttpPost, ActionName("DeleteEnrolment")]
        public ActionResult DeleteEnrolment2(int unitid, int studentid) {
            //Find the student in the database with the same id that was passed in.
            Student student = db.Students.Find(studentid);

            //Loop through all the enrolments(units) in the student.
            Enrolment enrolment = new Enrolment();
            foreach (var loopenrolment in student.Enrolments) {
                //if the id of the selected enrolment(unit) is the same as a unit inside the student enrolments,
                //then add the enrolment(unit) to the enrolment object.
                if (loopenrolment.Unit_Id == unitid) {
                    enrolment = loopenrolment;
                }
            }

            //Remove the Enrolment(unit) from the student object, and save the changes into the database
            student.Enrolments.Remove(enrolment);

            db.Entry(student).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Edit", "Student", new { id = studentid });
        }


        //
        // GET: /Student/Delete/5

        public ActionResult Delete(int id) {
            //Find the student in the database with the same id that was passed in.
            Student student = db.Students.Find(id);
            //redirect to the delete page with the student passed in.
            return View(student);
        }

        //
        // POST: /Student/Delete/5

        //When the "are you sure" DeleteStudent button is pressed
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id) {
            //Find the student in the database with the same id that was passed in.
            Student student = db.Students.Find(id);
            //Get all the enrolments(units) from the student and store them in a list.
            List<Enrolment> enrolmentList = student.Enrolments.ToList();

            //Loop through all the enrolemnt(units) in the student, and make sure they are deleted from the database
            //before deleting the student to avoid any errors.
            foreach (var enrolment in enrolmentList) {
                db.Enrolments.Remove(enrolment);
            }

            //Remove the student from the database, and save the database changes. Redirect to the main index page.
            db.Students.Remove(student);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing) {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}