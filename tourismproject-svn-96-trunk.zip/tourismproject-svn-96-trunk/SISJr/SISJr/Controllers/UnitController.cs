﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SISJr.Models;
using SISJr;

namespace SISJr.Controllers
{
    public class UnitController : Controller
    {
        private Entities db = new Entities();

        //
        // GET: /Unit/
        // Displaing Units from the database and specific Qualification with 
        // related Units also Searches for letters/words in the Units table
        public ActionResult Index(string unitsName, string nationalCode)
        {
            var units = from u in db.Units
                        select u;
            if (!String.IsNullOrEmpty(unitsName))
            {
                units = units.Where(c => c.Name.Contains(unitsName));
            }

            ViewBag.Name = new SelectList(db.Qualifications, "Id", "Name");
            return View(units);
        }

        //
        // GET: /Unit/Details/5

        public ViewResult Details(int id)
        {
            Unit unit = db.Units.Find(id);
            return View(unit);
        }

        //
        // GET: /Unit/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Unit/Create

        [HttpPost]
        public ActionResult Create(Unit unit)
        {
            var natCode = unit.NationalCode;
            var units = (from c in db.Units
                         where c.NationalCode == natCode
                         select c).ToList();
                if (ModelState.IsValid)
                {
                    if (units.Count > 0)
                    {
                        ViewBag.Duplicate = "National Code " + natCode + "already exists";
                    }
                    else
                    {
                        db.Units.Add(unit);
                        db.SaveChanges();
                        ViewBag.SuccessMsg = "Your unit " + unit.Name + " with National Code" + unit.NationalCode + " being added to the database.";
                        //return RedirectToAction("Index");
                    }
                }
            return View(unit);
        }

        //
        // GET: /Unit/Edit/5

        public ActionResult Edit(int id)
        {
            Unit unit = db.Units.Find(id);
            return View(unit);
        }

        //
        // POST: /Unit/Edit/5

        [HttpPost]
        public ActionResult Edit(Unit unit)
        {
            if (ModelState.IsValid)
            {
                db.Entry(unit).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(unit);
        }

        //
        // GET: /Unit/Delete/5

        public ActionResult Delete(int id)
        {
            Unit unit = db.Units.Find(id);
            return View(unit);
        }

        //
        // POST: /Unit/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            Unit unit = db.Units.Find(id);
            db.Units.Remove(unit);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}