﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SISJr.Models;
using SISJr;

namespace SISJr.Controllers
{ 
    public class QualificationController : Controller
    {
        private Entities db = new Entities();

        //
        // GET: /Qualification/

        public ViewResult Index()
        {
            //populates the view with data from unit table
            return View(db.Qualifications.ToList());
        }

        //
        // GET: /Qualification/Details/5

        public ViewResult Details(int id)
        {
            //retrieves and displays qualification details
            Qualification qualification = db.Qualifications.Find(id);
            return View(qualification);
        }

        // GET: AddUnit
        public ViewResult AddUnit(int qualId)
        {
            //passes the qualification id into the addUnit page
            ViewBag.qualId = qualId;
            return View(db.Units.ToList());
        }

        // GET: /Unit/Create

        //
        // POST: /Unit/Create

        public ViewResult Add()
        {

            return View();
        }

        //handles the adding of a unit to the qualification
        [HttpPost]
        public ActionResult AddUnit(int unitId, int qualId, bool core)
        {
            var unit = db.Units.Find(unitId);
            if (ModelState.IsValid && unit != null)
            {
                ViewBag.addUnitError = "";
                QualificationUnit qu = db.QualificationUnits.Where(quu => quu.Units_Id == unit.Id && quu.Qualifications_Id == qualId).FirstOrDefault();
                if (qu == null)
                {
                    qu = new QualificationUnit();
                    qu.Units_Id = unit.Id;
                    qu.Qualifications_Id = qualId;
                    qu.Core = core;
                    //qu.Qualification = new Qualification();
                    //qu.Unit = new Unit();

                    db.QualificationUnits.Add(qu);
                    db.SaveChanges();

                    return RedirectToAction("Edit", "Qualification", new { id = qualId });
                }
                else
                {
                    //ViewBag.addUnitError = "ERROR";
                    //ViewBag.testid = qualId;
                    //return View(db.Units.ToList());
                    return RedirectToAction("Edit", "Qualification", new { id = qualId });
                }
            }
            ViewBag.qualId = qualId;
            //ViewBag.addUnitError = "Can not add unit, unit already exists";
           //return View(db.Units.ToList());
            return RedirectToAction("Edit", "Qualification", new { id = qualId });
        }
        

        // GET: /Qualification/Create

        public ActionResult Create()
        {
            return View();
        } 

        //
        
        // POST: /Qualification/Create

        [HttpPost]
        public ActionResult Create(Qualification qualification)
        {
            if (ModelState.IsValid)
            {   //checks if the textbox is empty
                if (qualification.Name == null || qualification.NationalCode == null || qualification.TafeCode == null)
                {
                    //displays error message
                    ViewBag.qualBlankError = "Field(s) are blank! Please re-enter data!";
                    return View(qualification);
                }
                db.Qualifications.Add(qualification);
                db.SaveChanges();
                return RedirectToAction("Index");  
            }

            return View(qualification);
        }
        
        //
        // GET: /Qualification/Edit/5
    
        public ActionResult Edit(int id)
        {
            //redirects to edit page
            Qualification qualification = db.Qualifications.Find(id);
            return View(qualification);
        }

        //
        // POST: /Qualification/Edit/5

        //handles the editing process of the edit page
        [HttpPost]
        public ActionResult Edit(Qualification qualification)
        {
            if (ModelState.IsValid)
            {
                if (qualification.Name == null || qualification.NationalCode == null || qualification.TafeCode == null)
                {
                    //ViewBag.qualBlankError = "Field(s) are blank! Please re-enter data!";
                    //return View(qualification);
                    return RedirectToAction("Edit", "Qualification", new { id = qualification.Id });
                }

                db.Entry(qualification).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(qualification);
        }

        //
        // GET: /Qualification/Delete/5
        
        public ActionResult Delete(int id)
        {
            Qualification qualification = db.Qualifications.Find(id);
            return View(qualification);
        }

        //
        // POST: /Qualification/Delete/5

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {            
            Qualification qualification = db.Qualifications.Find(id);
            List<QualificationUnit> qualUnitList = qualification.QualificationUnits.ToList();

            foreach (var units in qualUnitList)
            {
                qualification.QualificationUnits.Remove(units);
            }

            List<Student> studentList = db.Students.ToList();
            foreach (var students in studentList)
            {
                if (students.Qualifications == qualification)
                {
                    students.Qualifications.Remove(qualification);
                }
            }

            db.Qualifications.Remove(qualification);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        //handles deleteUnit page

        public ActionResult DeleteUnit(int qualId, int unitId)
        {
            QualificationUnit qualificationUnit = new QualificationUnit();
            qualificationUnit.Qualifications_Id = qualId;
            qualificationUnit.Units_Id = unitId;



            ViewBag.QualId = qualId;
            ViewBag.UnitId = unitId;           

            return View(qualificationUnit);
            
        }

        //deleteUnit confirmation page

        [HttpPost, ActionName("DeleteUnit")]
        public ActionResult DeleteUnitConfirm(int qualId, int unitId)
        {
            QualificationUnit qualUnit = db.QualificationUnits.Find(qualId, unitId);
            
            db.QualificationUnits.Remove(qualUnit);
                db.SaveChanges();

            //return RedirectToAction("Index");
            return RedirectToAction("Edit", "Qualification", new { id = qualId });
        }

        protected override void Dispose(bool disposing)
        {
            db.Dispose();
            base.Dispose(disposing);
        }
    }
}