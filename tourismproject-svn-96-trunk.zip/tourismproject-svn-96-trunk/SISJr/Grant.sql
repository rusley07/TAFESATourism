﻿IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = 'IIS APPPOOL\DefaultAppPool')
BEGIN
    CREATE LOGIN [IIS APPPOOL\DefaultAppPool] 
      FROM WINDOWS WITH DEFAULT_DATABASE=[master], 
      DEFAULT_LANGUAGE=[us_english]
END
GO
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'SISJrUser')
BEGIN
	CREATE USER [SISJrUser] 
	  FOR LOGIN [IIS APPPOOL\DefaultAppPool]
	EXEC sp_addrolemember 'db_owner', 'SISJrUser'
END
GO
GO